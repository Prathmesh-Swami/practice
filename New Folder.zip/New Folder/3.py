import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Employee_Salary.csv")

print(df.columns)
print(df.shape)
print(df.size)
print(df.head())
print(df.tail())
print(df.dtypes)
print(df.describe())

print(df.isnull().sum())
df = df.fillna(method= 'ffill')

cols = ['Experience_Years','Salary','Age']

for col in cols:
	print(df[col].min())
	print(df[col].max())
	print(df[col].mean())
	print(df[col].median())
	print(df[col].mode())
	print(df[col].std())
	print(df[col].kurt())
	print(df[col].skew())
	print(df[col].describe())

print("-----------------------------------------")
print(df['Age'].groupby(df['Gender']).min())

print("-----------------------------------------")
print(df['Age'].groupby(df['Gender']).max())

print("-----------------------------------------")
print(df['Age'].groupby(df['Gender']).mean())

print("-----------------------------------------")
print(df['Age'].groupby(df['Gender']).median())


print("-----------------------------------------")
print(df['Age'].groupby(df['Gender']).std())

sns.boxplot(df['Salary'])
plt.show()

sns.scatterplot(data = df,x='Salary',y='Age')
plt.show()

sns.histplot(data = df,x='Age',hue='Gender',multiple= 'dodge')
plt.show()