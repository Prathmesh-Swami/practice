import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics

df=pd.read_csv("Boston.csv")

print(df.shape)
print(df.columns)
print(df.size)
print(df.dtypes)
print(df.describe())
print(df.head())
print(df.tail())
print(df.info())

print(df.isnull().sum())
df = df.fillna(method = 'ffill')

sns.boxplot(df['rm'])
plt.show()
sns.boxplot(df['lstat'])
plt.show()

def remove_outlier(df,colm):
	Q1 = df[colm].quantile(0.25)
	Q3 = df[colm].quantile(0.75)
	IQR = Q3 - Q1
	low = Q1-1.5*IQR
	high = Q3+1.5*IQR
	df = df[((df[colm]>=low) & (df[colm]<=high))]
	return df 

df = remove_outlier(df,'rm')
df = remove_outlier(df,'rm')
df = remove_outlier(df,'lstat')

sns.boxplot(df['rm'])
plt.show()
sns.boxplot(df['lstat'])
plt.show()
sns.heatmap(df.corr(),annot=True)
plt.show()
x = df[['rm','lstat']]
y = df[['medv']]

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=42)

model = LinearRegression()
model.fit(x_train,y_train)
y_predict = model.predict(x_test)
print(y_predict)

print(model.score(x_test,y_test))


print(metrics.mean_absolute_error(y_test,y_predict))

