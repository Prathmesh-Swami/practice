import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df  = pd.read_csv('titanic.csv')
print('Dataset Read Sucessfully')

print(df.shape, "\n" , df.size ,"\n" , df.columns , "\n" , df.info() , "\n", df.describe(), "\n", df.dtypes ,"\n")

print(df.isna().sum())
df['Age'].fillna(df['Age'].median(), inplace = True)
print(df.isna().sum())

fig, axes = plt.subplots(1,2)
fig.suptitle("Histogram for age and fair")
sns.histplot(data = df , x= 'Age' , ax = axes[0])
sns.histplot(data = df , x= 'Fare' , ax = axes[1])
plt.show()

fig, axes = plt.subplots(2,2)
fig.suptitle("Histograms")
sns.histplot(data = df, x= 'Age' , hue = 'Survived' ,multiple = 'dodge', ax = axes[0,0])
sns.histplot(data = df, x= 'Fare' , hue = 'Survived' ,multiple = 'dodge', ax = axes[0,1])
sns.histplot(data = df, x= 'Age' , hue  = 'Sex',multiple = 'dodge', ax = axes[1,0])
sns.histplot(data = df,x= 'Age' , hue  = 'Sex',multiple = 'dodge', ax = axes[1,1])
plt.show()
