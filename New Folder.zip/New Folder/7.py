import nltk
import re
nltk.download('punkt')
nltk.download('corpus')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')


text = "My Name is Kalpesh Padmawar Im prerforming the 7 th practical"
#Sentance Tokenization
from nltk.tokenize import sent_tokenize
Tokenized_text = sent_tokenize(text)
print(Tokenized_text)

#Word Tokenization
from nltk.tokenize import word_tokenize
Tokenized_word = word_tokenize(text)
print(Tokenized_word)

#Stop Words
from nltk.corpus import stopwords
stop_word = set(stopwords.words('english'))
print(stop_word)

#Removing Stop Words
text1 = "How to remove Stop Words using Nltk Library in python ? how lenghty!!"
text1 = re.sub('[^a-zA-Z]' , ' ' ,text1)
Tokens = word_tokenize(text1.lower())
filtered_text = []
for w in Tokens:
	if w not in stop_word:
		filtered_text.append(w)
		print(w)	
print(Tokens)
print(filtered_text)

#stemming
from nltk.stem import PorterStemmer
word = ['studies , studying, playing']
ps = PorterStemmer()
rootword = []
for w in word:
	root_word = ps.stem(w)
print(root_word)	
		
#lemmatization
from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()
text = 'studies studying cries cry'
tokenization = nltk.word_tokenize(text)
for w in tokenization:
	print(w , " Lemma is ", wordnet_lemmatizer.lemmatize(w))

#Pos Tagging	
from nltk.tokenize import word_tokenize
text = 'The Black Shirt fit him Perfectly'
words = word_tokenize(text)
for word in words:
	print(nltk.pos_tag([word]))
		
#TF IDF calculation		
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
t1 = 'Jupiter is the Largest Planet'
t2 = 'mars is forth planet form sun'
string = [t1,t2]
tfidf = TfidfVectorizer()

result = tfidf.fit_transform(string)
print("Word indices",tfidf.vocabulary_)
print("Result ",result)