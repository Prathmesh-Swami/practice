import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('iris.csv')
print("Dataset Read Succesfully")

print("\n",df.shape ,"\n",df.size ,"\n",df.info() ,"\n",df.head() ,"\n",df.describe() ,"\n")

print(df.isna().sum())
df.fillna(0)
print(df.isna().sum())
#Boxplot
fig, axes = plt.subplots(2,2)
fig.suptitle("BoxPlot for every entry ")
sns.boxplot(data = df , x = 'sepal.length' , hue = 'variety' , ax = axes[0,0])
sns.boxplot(data = df , x = 'sepal.width' , hue = 'variety' , ax = axes[0,1])
sns.boxplot(data = df , x = 'petal.length' , hue = 'variety' , ax = axes[1,0])
sns.boxplot(data = df , x = 'petal.width' , hue = 'variety' ,ax = axes[1,1])
plt.show()
#Histogram
fig , axes = plt.subplots(2,2)
fig.suptitle("Histogram for every Entry")
sns.histplot(data = df, x = 'sepal.length' , hue = 'variety' ,multiple= 'dodge', ax = axes[0,0])
sns.histplot(data = df , x = 'sepal.width' , hue = 'variety' ,multiple= 'dodge', ax = axes[0,1])
sns.histplot(data = df , x = 'petal.length' , hue = 'variety' ,multiple= 'dodge', ax = axes[1,0])
sns.histplot(data = df , x = 'petal.width' , hue = 'variety' ,multiple= 'dodge', ax = axes[1,1])
plt.show()
