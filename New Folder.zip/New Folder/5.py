import pandas as pd 
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("Social_Network_Ads.csv")

print(df.shape)
print(df.size)
print(df.columns)
print(df.dtypes)
print(df.info())
print(df.head())
print(df.tail())
print(df.describe())

print(df.isnull().sum())
df = df.fillna(0)

df['Gender']=df['Gender'].astype('category')
df['Gender'].replace(['Male','Female'],['0','1'],inplace=True)
print(df.head())


sns.boxplot(df['EstimatedSalary'])
plt.show()
sns.boxplot(df['Age'])
plt.show()

def remove_outlier(df,var): 
	Q1 = df[var].quantile(0.25)
	Q3 = df[var].quantile(0.75)
	IQR = Q3-Q1
	low = Q1 - 1.5*IQR
	high = Q3+ 1.5*IQR
	df = df[((df[var]>=low) & (df[var]<=high))]
	return df

df = remove_outlier(df,'EstimatedSalary')
df = remove_outlier(df,'Age')

sns.boxplot(df['EstimatedSalary'])
plt.show()
sns.boxplot(df['Age'])
plt.show()
sns.heatmap(df.corr(),annot=True)
plt.show()
x = df[['Gender','EstimatedSalary','Age']]
y = df['Purchased']

X_train, X_test, Y_train, Y_test = train_test_split(x,y, test_size = 0.2, random_state = 42)

#normalization
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

#training
model = LogisticRegression()
model.fit(X_train, Y_train)
Y_predict = model.predict(X_test)
print(Y_predict)

print(classification_report(Y_test,Y_predict))
cm = confusion_matrix(Y_test,Y_predict)

sns.heatmap(cm,annot=True)
plt.show()