import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

df = pd.read_csv('titanic.csv')

print("\n",df.shape, "\n",df.size , "\n",df.columns, "\n",df.dtypes, "\n",df.describe(), "\n", df.info(), "\n", df.head() , "\n",df.tail().T,"\n", df.sample(5).T)

print("Null Values : \n", df.isna().sum())
df['Age'].fillna(method = 'ffill' , inplace = True)
print("Null Values : \n", df.isna().sum())
#Boxplot 1 varible
fig , axes  = plt.subplots(1,2)
fig.suptitle("Box plot For Age and Fair")
sns.boxplot(data = df , x = 'Age', ax = axes[0])
sns.boxplot(data = df , x = 'Fare', ax = axes[1])
plt.show()
#Boxplot 2 Varible
fig, axes = plt.subplots(2,2)
fig.suptitle("Boxplots with 2 parameters")
sns.boxplot(data = df , x = 'Survived' , y = 'Age', hue = 'Survived', ax = axes[0,0])
sns.boxplot(data = df , x = 'Survived', y = 'Fare', hue = 'Survived' , ax = axes[0,1])
sns.boxplot(data = df , x= 'Sex', y = 'Age', hue = 'Sex' , ax = axes[1,0])
sns.boxplot(data = df , x= 'Sex', y = 'Fare', hue = 'Sex' , ax = axes[1,1])
plt.show()
#Boxplot 3 Varible
fig ,axes = plt.subplots(1,2)
fig.suptitle(" Boxplot with 3 Parameters")
sns.boxplot(data = df, x = 'Sex', y = 'Age' , hue =  'Survived' , ax = axes[0])
sns.boxplot(data = df, x = 'Sex', y = 'Fare' , hue = 'Survived' , ax = axes[1])
plt.show()
