import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix,classification_report

df=pd.read_csv("Iris.csv")
print(df.shape)
print(df.size)
print(df.columns)
print(df.dtypes)
print(df.info())
print(df.head())
print(df.tail())
print(df.describe())

print(df.isnull().sum())
df = df.fillna(0)



sns.boxplot(df['SepalLengthCm'])
plt.show()
sns.boxplot(df['SepalWidthCm'])
plt.show()
sns.boxplot(df['PetalLengthCm'])
plt.show()
sns.boxplot(df['PetalWidthCm'])
plt.show()

def remove_outlier(df,var): 
	Q1 = df[var].quantile(0.25)
	Q3 = df[var].quantile(0.75)
	IQR = Q3-Q1
	low = Q1 - 1.5*IQR
	high = Q3+ 1.5*IQR
	df = df[((df[var]>=low) & (df[var]<=high))]
	return df

df = remove_outlier(df,'SepalLengthCm')
df = remove_outlier(df,'SepalWidthCm')
df = remove_outlier(df,'PetalLengthCm')
df = remove_outlier(df,'PetalWidthCm')

sns.boxplot(df['SepalLengthCm'])
plt.show()
sns.boxplot(df['SepalWidthCm'])
plt.show()
sns.boxplot(df['PetalLengthCm'])
plt.show()
sns.boxplot(df['PetalWidthCm'])
plt.show()


sns.heatmap(df.corr(),annot=True)
plt.show()

x = df[['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']]
y = df['Species']

X_train, X_test, Y_train, Y_test = train_test_split(x,y, test_size = 0.2, random_state = 42)



#training
model = GaussianNB()
model.fit(X_train, Y_train)
Y_predict = model.predict(X_test)
print(Y_predict)

print(classification_report(Y_test,Y_predict))
cm = confusion_matrix(Y_test,Y_predict)

sns.heatmap(cm,annot=True)
plt.show()