import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("student_data.csv")

print(df.info())
print(df.describe())
print(df.columns)
print(df.size)
print(df.shape)
print(df.head())
print(df.tail())
print(df.dtypes)

print(df.isnull().sum())
df = df.fillna(0)

df['age']=df['age'].astype("int64")
print(df['age'].dtypes)

sns.boxplot(data = df,x='G1')
plt.show()
sns.boxplot(data = df,x='G2')
plt.show()
sns.boxplot(data = df,x='G3')
plt.show()

def removeoutlier(data,colm):
	q1=data[colm].quantile(0.25)
	q3=data[colm].quantile(0.75)
	IQR = q3-q1
	low = q1-1.5*IQR
	high = q3+1.5*IQR
	data = data[((data[colm]>=low) & (data[colm]<=high))]
	return data

df = removeoutlier(df,'G1')

df = removeoutlier(df,'G2')

df = removeoutlier(df,'G3')

sns.boxplot(data = df,x='G1')
plt.show()
sns.boxplot(data = df,x='G2')
plt.show()
sns.boxplot(data = df,x='G3')
plt.show()

