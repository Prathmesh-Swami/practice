import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("student_data.csv")
print(df.head())
print(df.tail())
print(df.info())
print(df.describe())
print(df.shape)
print(df.dtypes)
print(df.columns)
print(df.info())
print(df.isnull().sum())

df = df.fillna(0)
print(df.isnull().sum())

df=df.astype({'sex':'category'})
print(df['sex'].dtype)
df['sex']=df['sex'].cat.codes
print(df['sex'])

scaler = StandardScaler()

df[['G1','G3']] = scaler.fit_transform(df[['G1','G3']])
print(df.head(10))
